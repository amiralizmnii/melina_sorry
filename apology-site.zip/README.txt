1- frontend را روی Vercel منتشر کن.
2- backend را روی Render منتشر کن.
3- فایل .env.example را به .env تبدیل کن و BOT_TOKEN و CHAT_ID را وارد کن.
4- در frontend/script.js آدرس YOUR-BACKEND.onrender.com را با آدرس Render خودت جایگزین کن.
